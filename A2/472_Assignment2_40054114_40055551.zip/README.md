Github URL: https://github.com/danseremet/comp472-assignments/tree/main/A2


# Assignment 2

#### Authors:
- Dan Seremet, 40054114
- Joey Abou Chaker, 40055551

## How to run the code

1. Download or clone ` git clone https://github.com/danseremet/comp472-assignments.git` the project.
2. Assignment 2 is located in A2 folder.
3. Run `python main.py`

## Notes
- The 50 random puzzles output files are in output_files_500/.
